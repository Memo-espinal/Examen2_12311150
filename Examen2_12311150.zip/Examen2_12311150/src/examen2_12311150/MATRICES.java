/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen2_12311150;

/**
 *
 * @author Eduardo Aguilar
 */
public class MATRICES {
    int [][]matriz;
    public MATRICES(int[][]Matriz){
        this.matriz=Matriz;
    }
    public String Imprimir(){
        String Impresion="";
        for(int i=0;i<matriz.length;i++){
            for(int j=0;j<matriz[0].length;j++){
                Impresion+=matriz[i][j];
            }
        }
        return Impresion;
    }
}
